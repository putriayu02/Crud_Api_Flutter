package com.example.crud_api_putriayu

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
